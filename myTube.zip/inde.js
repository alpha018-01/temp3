function alertInputValue() {

    const inputValue = document.getElementById("url")
    const URL = inputElement.value;
    alert(URL);
  
}
